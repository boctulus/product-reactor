<?php

/*
	Settings
*/


return [
	'API_KEY' => '9cbe0ce48e8c9FX'
];
