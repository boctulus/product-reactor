<?php

/*
	Settings
*/

/*
	API
*/
define('API_KEY', 'woo2');
define('SECRET',  '1234');
